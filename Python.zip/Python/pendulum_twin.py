import zmq
import numpy as np
import onnxruntime as ort
import time
import threading


MODEL_PATH = "./balancer.onnx"
#MODEL_PATH = "./calmer.onnx"

STACKED_VECTORS = 4 
TIME_STEP = 0.045

class RotaryPendulumController(object):
    def __init__(self, model_path):
        sess_options = ort.SessionOptions()

        # Disable all graph optimizations (or choose a lower optimization level)
        sess_options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_DISABLE_ALL

        # Set execution mode to sequential
        sess_options.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL

        self.model = ort.InferenceSession(model_path, sess_options)
        self.history = np.zeros((STACKED_VECTORS, 4), dtype=np.float32)
        self.context = zmq.Context()
        self.socket = self.context.socket(zmq.REQ)
        self.socket.connect("tcp://localhost:5555")  # Connect to Unity server

    def get_observation(self):
        
        # Get values
        # print("Getting observation...")
        self.socket.send_string("GET_OBS")
        # Receive observation from Unity Build
        obs = self.socket.recv_json()
        # print("Received!")
        return np.array(list(obs.values()), dtype=np.float32)

    def set_servo_position(self, position):
        control_msg = {"position": position}
        # print("Sending response...")
        self.socket.send_json(control_msg)
        self.socket.recv_string()
        # print("Sent!")

    def run(self):
        while True:
            start_time = time.time()

            obs = self.get_observation()
            #obs += np.random.normal(0, 0.1, size=obs.shape)
            self.history = np.roll(self.history, shift=-1, axis=0)
            self.history[-1] = obs

            # Stack last 4 observations (flattened) for model input
            stacked_obs = self.history.flatten().reshape(1, -1)
            input_name = self.model.get_inputs()[0].name

            
            action = self.model.run(None, {input_name: stacked_obs})
            control = action[4].item()
            # print(obs, control)

            self.set_servo_position(control * 1.57)
            print(control)

            end_time = time.time()
            time_spent = end_time - start_time
            #print(time_spent)
            time.sleep(abs(TIME_STEP - time_spent))  # Match training timestep

def main():
    controller = RotaryPendulumController(MODEL_PATH)
    controller.run()

if __name__ == '__main__':
    main()

